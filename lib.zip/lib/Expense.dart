class Expense {
  final String memberName;
  final double amount;

  Expense({required this.memberName, required this.amount});
}