class User {
  String name ;
  String last_name ;
  String national_code ;
  User(this.name , this.last_name , this.national_code) ;
}