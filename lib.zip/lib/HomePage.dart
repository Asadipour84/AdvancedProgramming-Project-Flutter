import 'User.dart';
class HomePage {
  User user ;
  HomePage(this.user) ;
}