class Groups {
    List <int> bills ;
    List <int> rent ;
    List <int> education ;
    Groups() :bills = [] , rent = [] , education = [] ;
    
}