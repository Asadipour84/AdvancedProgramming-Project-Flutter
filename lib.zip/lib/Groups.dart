class Groups {
    final String name ;
    final List<String>  members ;
    Groups({required this.name , List<String>? members}) : members = members ?? [] ;
}